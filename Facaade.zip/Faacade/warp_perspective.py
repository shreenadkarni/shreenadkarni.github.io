"""Image transforms: Warp using perspective transform"""

import sys
import os
import numpy as np
import cv2
from scipy.stats import norm
from scipy.signal import convolve2d
import math

sourcefolder = os.path.abspath(os.path.join(os.curdir, 'images', 'source'))
outfolder = os.path.abspath(os.path.join(os.curdir, 'images', 'output'))

print 'Searching for images in {} folder'.format(sourcefolder)

  # Extensions recognized by opencv
exts = ['.bmp', '.pbm', '.pgm', '.ppm', '.sr', '.ras', '.jpeg', '.jpg', 
    '.jpe', '.jp2', '.tiff', '.tif', '.png']

# For every image in the source directory
for dirname, dirnames, filenames in os.walk(sourcefolder):
  setname = os.path.split(dirname)[1]

  white_img = None

for filename in filenames:
  name, ext = os.path.splitext(filename)
  if ext in exts:

    if 'white' in name:
      print "Reading image {} from {}.".format(filename, dirname)
      white_img = cv2.imread(os.path.join(dirname, filename))

if white_img == None:
  print "Did not find white images in folder: " + dirname

white_img = white_img.astype(float)

# Read image
height, width = white_img.shape[:2]

# Perspective transform
pts1 = np.float32([[200, 200], [800, 200], [200, 800], [800, 800]])
# pts2 = np.float32([[75, 75], [75, 225], [500, 75], [500, 225]])
pts2 = np.float32([[400, 200], [500, 200], [40, 800], [940, 700]])

M_persp = cv2.getPerspectiveTransform(pts1, pts2)  # compute perspective transform (needs exactly 4 points)
print "Computed perspective transform matrix:"
print M_persp

img_persp = cv2.warpPerspective(white_img, M_persp, (900, 600))  # apply transform; last arg is output image size

# Create outfolder if it doesn't exist
try:
    os.stat(outfolder)
except:
    os.mkdir(outfolder)

print "Writing images to folder {}".format(os.path.join(outfolder, setname))

cv2.imwrite(os.path.join(outfolder, setname + ext),
            img_persp)