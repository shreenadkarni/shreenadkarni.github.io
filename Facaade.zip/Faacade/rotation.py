"""Image transforms: Rotation"""

import sys
import os
import numpy as np
import cv2
from scipy.stats import norm
from scipy.signal import convolve2d
import math

sourcefolder = os.path.abspath(os.path.join(os.curdir, 'images', 'source'))
outfolder = os.path.abspath(os.path.join(os.curdir, 'images', 'output'))

print 'Searching for images in {} folder'.format(sourcefolder)

  # Extensions recognized by opencv
exts = ['.bmp', '.pbm', '.pgm', '.ppm', '.sr', '.ras', '.jpeg', '.jpg', 
    '.jpe', '.jp2', '.tiff', '.tif', '.png']

# For every image in the source directory
for dirname, dirnames, filenames in os.walk(sourcefolder):
  setname = os.path.split(dirname)[1]

  white_img = None

for filename in filenames:
  name, ext = os.path.splitext(filename)
  if ext in exts:

    if 'white' in name:
      print "Reading image {} from {}.".format(filename, dirname)
      white_img = cv2.imread(os.path.join(dirname, filename))

if white_img == None:
  print "Did not find white images in folder: " + dirname

white_img = white_img.astype(float)

# Read image
height, width = white_img.shape[:2]

# Rotation around origin (0, 0)
M_rot = cv2.getRotationMatrix2D((400, 300), 45, 1)  # 45 deg, scale = 1
print "Rotation matrix (around origin):"
print M_rot
img_rot = cv2.warpAffine(white_img, M_rot, (width, height))

# Rotation around center (i.e. translation + rotation)
M_rot_center = cv2.getRotationMatrix2D((width / 2, height / 2), -45, 1)  # -45 deg, scale = 1
print "\nRotation matrix (around center):"
print M_rot_center
img_rot_center = cv2.warpAffine(white_img, M_rot_center, (width, height))

# Create outfolder if it doesn't exist
try:
    os.stat(outfolder)
except:
    os.mkdir(outfolder)

print "Writing images to folder {}".format(os.path.join(outfolder, setname))

cv2.imwrite(os.path.join(outfolder, setname + "_orig_rot" + ext),
            img_rot)

cv2.imwrite(os.path.join(outfolder, setname + "_center_rot" + ext),
            img_rot_center)





