"""Image transforms: Translation"""

import sys
import os
import numpy as np
import cv2
from scipy.stats import norm
from scipy.signal import convolve2d
import math

sourcefolder = os.path.abspath(os.path.join(os.curdir, 'images', 'source'))
outfolder = os.path.abspath(os.path.join(os.curdir, 'images', 'output'))

print 'Searching for images in {} folder'.format(sourcefolder)

  # Extensions recognized by opencv
exts = ['.bmp', '.pbm', '.pgm', '.ppm', '.sr', '.ras', '.jpeg', '.jpg', 
    '.jpe', '.jp2', '.tiff', '.tif', '.png']

# For every image in the source directory
for dirname, dirnames, filenames in os.walk(sourcefolder):
  setname = os.path.split(dirname)[1]

  white_img = None

for filename in filenames:
  name, ext = os.path.splitext(filename)
  if ext in exts:

    if 'white' in name:
      print "Reading image {} from {}.".format(filename, dirname)
      white_img = cv2.imread(os.path.join(dirname, filename))

if white_img == None:
  print "Did not find white images in folder: " + dirname

white_img = white_img.astype(float)

# Read image
height, width = white_img.shape[:2]


# Translation
M_trans = np.float32(
    [[1, 0, 100],
     [0, 1,  50]])
print "Translation matrix:"
print M_trans
img_trans = cv2.warpAffine(white_img, M_trans, (width, height))  # note: last arg is size of output image (width, height)
# cv2.imshow("Translation", img_trans)

# Create outfolder if it doesn't exist
try:
    os.stat(outfolder)
except:
    os.mkdir(outfolder)

print "Writing images to folder {}".format(os.path.join(outfolder, setname))

cv2.imwrite(os.path.join(outfolder, setname + ext),
            img_trans)